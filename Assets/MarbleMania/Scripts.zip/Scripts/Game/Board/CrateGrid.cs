﻿using System;
using System.Collections.Generic;
using Anvil;
using Anvil.Legacy;
using Drawing;
using NaughtyAttributes;
using UnityEngine;

namespace MarbleMania
{
    // public class CrateCell : GridCell
    // {
    //     private Crate _crate;
    //
    //     public Crate Crate => _crate;
    //     public bool IsEmpty => _crate == null;
    //     public void AddCrate(Tray tray)
    //     {
    //         _crate = tray;
    //     }
    //
    //     public void RemoveTray()
    //     {
    //         _crate = null;
    //     }
    // }

    [Serializable]
    public class CrateGridData
    {
        public List<CrateCellData> _gridData;
    }

    [Serializable]
    public class CrateCellData
    {
        public int row;
        public int col;
        public CrateData crate;
    }
    [Serializable]
    public class CrateData
    {
        public CrateType type;
        public List<ColorType> colorData;
    }

    // public class CrateGridCell
    public class CrateGrid : MonoBehaviourGizmos
    {
        [SerializeField] private CrateGridData _testData;

        [SerializeField] private Transform _rowContainer;
        [SerializeField] private bool drawCoord = false;
        [SerializeField] private float textSize = 0.3f;
        [SerializeField] private int _rowCount;
        [SerializeField] private int _colCount;
        // [SerializeField] private float _rowWidth;
        [SerializeField] private float _spacing;
        [SerializeField] private float _cellSize;
        private Crate[,] _crates;

        // [SerializeField] private CrateRow _rowPrefab;

        private List<CrateRow> _rows;
        private float _width;
        private float _height;

        [Button]
        private void Awake()
        {
            Generate(_testData);
        }

        private void Generate(CrateGridData gridData)
        {
            _crates = new Crate[_rowCount, _colCount];
            
            GameObjectPool.ClearManagedChild(_rowContainer.gameObject);
            int rowCount = gridData._gridData.Count;
            _height = rowCount * _cellSize + (rowCount - 1) * _spacing;
            _width = _colCount * _cellSize + (_colCount - 1) * _spacing;
            
            for (var i = 0; i < gridData._gridData.Count; i++)
            {
                var data = gridData._gridData[i];
                if (!IsValid(data.row, data.col) || GetCrate(data.row, data.col) != null) continue;
                var prefab = GameConfig.GetCratePrefab(data.crate.type);
                var crate = GameObjectPool.CreateObject<Crate>(transform, prefab.gameObject);
                if (crate == null) continue; 
                _crates[data.row, data.col] = crate;
                crate.Init(null, data.crate.colorData);
            }
        }

        private bool IsValid(int row, int col)
        {
            if (row >= _rowCount || col >= _colCount || row < 0 || col < 0)
            {
                return false;
            }
            return true;
        }
        private Crate GetCrate(int row, int col)
        {
            if (!IsValid(row, col)) return null;
            return _crates[row, col];
        }
        private Vector3 GetCellLocalPosition(int row, int col)
        {
            float x = -_width / 2 + _cellSize / 2 + row * (_cellSize + _spacing);
            float z = -_height / 2 + _cellSize / 2 + col * (_cellSize + _spacing);
            return new Vector3(x, 0, z);
        }

        private Vector3 GetRowLocalPosition(int i)
        {
            float x = -_width / 2 + _cellSize / 2 + i * (_cellSize + _spacing);
            return new Vector3(x, 0, 0);
        }

        public override void DrawGizmos()
        {
          
        }

        public bool CanRemoveCrate(Crate crate)
        {
            return true;
        }
    }
}