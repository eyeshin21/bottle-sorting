using UnityEngine;
using System;
using Gametamin;
using NUnit.Framework;

namespace MatchThree
{
    public abstract class LocalDataController<T> : IDataController<T>
    {
        protected string _key;
        protected T _defaultValue;
        protected T _value;
        private bool _isInited;

        public string Key => _key;

        public LocalDataController(string key, T defaultValue)
        {
            _key = key;
            _defaultValue = defaultValue;
        }

        public T Value
        {
            get
            {
                if (!_isInited)
                {
                    _isInited = true;
                    Init(Read());
                }

                return _value;
            }
            set
            {
                if (_isInited)
                {
                    if (!Equals(_value, value))
                    {
                        Set(value);
                        Write();
                    }
                }
                else
                {
                    _isInited = true;
                    Init(value);
                    Write();
                }
            }
        }

        protected virtual void Init(T value)
        {
            _value = value;
        }

        protected virtual void Set(T value)
        {
            _value = value;
        }

        public virtual void Reset()
        {
            Set(_defaultValue);
        }

        public virtual void Clear()
        {
            _isInited = false;
        }

        public abstract T Read();
        public abstract void Write();
        protected abstract bool Equals(T value1, T value2);

#if DEBUG_MODE
        public abstract void OnGUI(Action<T> setHandler = null);
#endif
    }

    public class LocalBoolDataController : LocalDataController<bool>
    {
        public LocalBoolDataController(string key, bool defaultValue = false) : base(key, defaultValue)
        {
            Label = key;
        }

        public override bool Read()
        {
            return UserDataSerializer.GetBool(_key, _defaultValue);
        }

        public override void Write()
        {
            UserDataSerializer.SetBool(_key, _value);
        }

        protected override bool Equals(bool value1, bool value2)
        {
            return value1 == value2;
        }


#if DEBUG_MODE
        bool _isGUIInited;

        public string Label { get; set; }

        public override void OnGUI(Action<bool> setHandler = null)
        {
            if (!_isGUIInited)
            {
                _isGUIInited = true;
                _value = Value;
            }

            bool value = GUILayout.Toggle(Value, Label);
            if (setHandler != null)
            {
                if (value != _value)
                {
                    setHandler(value);
                }
            }
            else
            {
                Value = value;
            }
        }
#endif
    }

    public class LocalIntDataController : LocalDataController<int>
    {
        public LocalIntDataController(string key, int defaultValue = 0) : base(key, defaultValue)
        {
            Label = key;
        }

        public override int Read()
        {
            return UserDataSerializer.GetInt(_key, _defaultValue);
        }

        public override void Write()
        {
            UserDataSerializer.SaveValue(_key, _value);
        }

        protected override bool Equals(int value1, int value2)
        {
            return value1 == value2;
        }

#if DEBUG_MODE
        string _text;
        bool _isGUIInited;

        protected override void Set(int value)
        {
            base.Set(value);
            _text = _value.ToString();
        }

        public string Label { get; set; }
        public float TextWidth { get; set; } = 120;

        public override void OnGUI(Action<int> setHandler = null)
        {
            if (!_isGUIInited)
            {
                _isGUIInited = true;
                _text = Value.ToString();
            }

            GUILayout.BeginHorizontal();
            {
                GUILayout.Label($"{Label}: ");
                if (TextWidth > 0)
                {
                    _text = GUILayout.TextField(_text, GUILayout.Width(TextWidth));
                }
                else
                {
                    _text = GUILayout.TextField(_text);
                }

                GUILayout.Space(5);
                bool guiEnabled = GUI.enabled;
                int value = _text.ToInt();
                GUI.enabled = guiEnabled && value != _value;
                if (GUILayout.Button("Set"))
                {
                    if (setHandler != null)
                    {
                        setHandler(value);
                        _text = _value.ToString(); // In case of value not changed (clamp, ...)
                    }
                    else
                    {
                        Value = value;
                    }
                }

                GUI.enabled = guiEnabled;
                GUILayout.FlexibleSpace();
            }
            GUILayout.EndHorizontal();
        }
#endif
    }

    public class LocalEnumHashSetDataController<TEnum> : LocalHashSetDataController<TEnum> where TEnum : struct, Enum
    {
        public LocalEnumHashSetDataController(string key) : base(key)
        {
        }

        protected override bool Parse(string part, out TEnum value)
        {
            bool ret = Enum.TryParse(part, out value);
            return ret;
        }
    }
}