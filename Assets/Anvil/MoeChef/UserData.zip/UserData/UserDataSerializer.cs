﻿using System;
using System.Collections.Generic;
using Gametamin;
using NaughtyAttributes;
using UnityEditor;
using UnityEngine;

namespace MatchThree
{
    public static partial class CommonKeys
    {
        public static readonly string DataVersion = "DataVersion";
        public static readonly string CurrentLevel = "CurrentLevel";
        public static readonly string MaxLevel = "MaxLevel";
        public static readonly string Board = "Board";
        public static readonly string TopScore = "TopScore";
        public static readonly string Coin = "Coin";
        public static readonly string Gem = "Gem";

        public static readonly string Sound = "Sound";
        public static readonly string Music = "Music";
        public static readonly string Vibration = "Vibration";

        public static readonly string ItemTutorial = "Tutorial";
        public static readonly string Tutorial = "Tutorial1";
        public static readonly string FoodStorage = "FoodStorage";
        public static readonly string MenuUnlocked = "MenuUnlocked";

        public static readonly string BoosterHammer = "BoosterHammer";
        public static readonly string BoosterBow = "BoosterBow";
        public static readonly string BoosterWand = "BoosterWand";
        public static readonly string BoosterHat = "BoosterHat";

        public static readonly string BeginLightball = "BeginLightball";
        public static readonly string BeginRocket = "BeginRocket";
        public static readonly string BeginTNT = "BeginTNT";
        public static readonly string Heart = "Heart";
        public static readonly string LastHeartTime = "LastHeartTime";
        
        public static readonly string Trainer = "Trainer";
        public static readonly string TrainerPosition = "TrainerPos";
    }

    [CreateAssetMenu(fileName = "UserDataSerializer", menuName = "PKM/User Data Serializer")]
    public partial class UserDataSerializer : ScriptableObject
    {
        public static bool Active => _instance != null;
        protected static UserDataSerializer _instance;
        private static bool _loaded;
        public static bool Loaded => _loaded;

        public static UserDataSerializer Instance
        {
            get
            {
                if (_instance == null)
                {
                    var type = typeof(UserDataSerializer);

                    // Try to load in "Resources"
                    _instance = Resources.Load<UserDataSerializer>(type.Name);
                    if (_instance != null)
                    {
                        // Init();
                        return _instance;
                    }
#if UNITY_EDITOR
                    // Try to load in "Editor Default Resources/Resources"
                    var path = $"Assets/Editor Default Resources/Resources/{type.Name}.asset";
                    _instance = AssetDatabase.LoadAssetAtPath<UserDataSerializer>(path);
                    if (_instance == null)
                    {
                        _instance = Resources.Load<UserDataSerializer>($"EditorConfigs/{type.Name}");
                    }
#endif
                }

                return _instance;
            }
        }

        [SerializeField] private DataSerializer defaultSerializer;


        [SerializeField] private LocalDataObject _localDataObject;
        [SerializeField] private string _dataVersion = "0.1";
        private IDataSerializer _localSerializer;
        private static IDataSerializer DataSerializer => Instance._localSerializer;

        public static void Init()
        {
            _loaded = false;
            if (Instance._localDataObject != null)
            {
                ClearCachedData();
                Instance._localDataObject.Init();
                Instance._localSerializer = Instance._localDataObject.Serializer;
                _loaded = true;
                Instance.OnLoaded();
                Debug.Log("user data loaded and ready");
            }
            else
            {
                string path = "";
#if UNITY_EDITOR
                path = Application.dataPath;
#else
            path = Application.persistentDataPath;
#endif
                if (DataSerializer == null)
                {
                    Instance._localSerializer = new LocalDataSerializer(path);
                    Debug.Log("local data serializer created");
                }

                if (DataSerializer == null)
                {
                    Debug.LogError("canot create data object");
                    return;
                }

                DataSerializer.Init();
                Debug.Log("User Data Serializer initialized, local data path: " + path);
                Debug.Log("user data loaded and ready");
                _loaded = true;
                Instance.OnLoaded();
            }
        }

        private void OnLoaded()
        {
            string saveVersion = GetValue(CommonKeys.DataVersion);
        }

#region data functions

        public static void SaveValue(string key, string value)
        {
            if (DataSerializer == null)
            {
                Debug.LogError("no Data forwarder assigned or key is empty");
                return;
            }

            DataSerializer.Save(key, value);
        }

        public static void SaveValue(string key, int value)
        {
            SaveValue(key, value.ToString());
        }

        public static void SaveValue(string key, float value)
        {
            SaveValue(key, value.ToString());
        }

        public static string GetValue(string key)
        {
            if (DataSerializer == null || string.IsNullOrEmpty(key))
            {
                Debug.LogError("no Data forwarder assigned or key is empty");
                return String.Empty;
            }

            return DataSerializer.GetString(key);
        }

        public static int GetInt(string key, int defaultValue = 0)
        {
            if (DataSerializer == null)
            {
                Debug.LogError("no Data forwarder assigned");
                return defaultValue;
            }

            if (string.IsNullOrEmpty(key))
            {
                Debug.LogError("key is empty");
                return defaultValue;
            }

            return DataSerializer.GetInt(key, defaultValue);
        }

        public static float GetFloat(string key, float defaultValue = 0)
        {
            if (DataSerializer == null || string.IsNullOrEmpty(key))
            {
                Debug.LogError("no Data forwarder assigned or key is empty");
                return defaultValue;
            }

            return DataSerializer.GetFloat(key, defaultValue);
        }

        public static bool GetBool(string key, bool defaultValue = false)
        {
            if (DataSerializer == null || string.IsNullOrEmpty(key))
            {
                Debug.LogError("no Data forwarder assigned or key is empty");
                return defaultValue;
            }

            return DataSerializer.GetBool(key, defaultValue);
        }

        public static void SetBool(string key, bool value)
        {
            if (DataSerializer == null || string.IsNullOrEmpty(key))
            {
                Debug.LogError("no Data forwarder assigned or key is empty");
                return;
            }

            DataSerializer.SetBool(key, value);
        }

#if UNITY_EDITOR
        [MenuItem("Game/Clear Data")]
#endif
        public static void ClearData()
        {
            _playedItemTutorials.Value.Clear();
            _playedItemTutorials.Write();
            if (DataSerializer == null)
            {
                Debug.LogError("no Data forwarder assigned or key is empty");
                return;
            }

            DataSerializer.Clear();
            ClearCachedData();
            Debug.Log("data cleared");
        }

        public static void ClearCachedData()
        {
            _trainerData = null;
            foreach (var dataController in _dataControllers)
            {
                dataController.Clear();
            }
        }

        public static void ForceClear()
        {
            if (DataSerializer == null)
            {
                Init();
            }

            DataSerializer?.Clear();
        }

#endregion


        [SerializeField] private string _testKey;
        [SerializeField] private string _testValue;

        [Button]
        public void ForceSave()
        {
            _trainerData.WriteAll();
            DataSerializer?.UpSync();
        }

        [Button]
        public void TestSave()
        {
            if (DataSerializer == null)
            {
                Init();
            }

            SaveValue(_testKey, _testValue);
        }

        private static void SetMaxLevel(int value)
        {
            MaxLevel = value;
        }

        private static void SetCurrentLevel(int value)
        {
            CurrentLevel = value;
        }


        public static int GetBeginBoosterAmount(BeginBoosterType boosterType)
        {
            switch (boosterType)
            {
                case BeginBoosterType.LightBall:
                    return BeginLightBall;
                case BeginBoosterType.Tnt:
                    return BeginTNT;
                case BeginBoosterType.Rocket:
                    return BeginRocket;
            }

            return 0;
        }

        public static void SetBeginBoosterAmount(BeginBoosterType boosterType, int amount)
        {
            switch (boosterType)
            {
                case BeginBoosterType.LightBall:
                    BeginLightBall = amount;
                    break;
                case BeginBoosterType.Tnt:
                    BeginTNT = amount;
                    break;
                case BeginBoosterType.Rocket:
                    BeginRocket = amount;
                    break;
            }
        }

        public static int AddBooster(BoosterType type, int amount)
        {
            int ret = 0;
            switch (type)
            {
                case BoosterType.Hammer:
                    ret = BoosterHammer += amount;
                    break;
                case BoosterType.Bow:
                    ret = BoosterBow += amount;
                    break;
                case BoosterType.Wand:
                    ret = BoosterWand += amount;
                    break;
                case BoosterType.Hat:
                    ret = BoosterHat += amount;
                    break;
            }
            type.ToChangedEventID().BroadcastEvent(ret);
            return ret;
        }
    }
}