﻿using System;
using System.Collections.Generic;
using Gametamin;
using MatchThree.Adventure;
using UnityEngine;

namespace MatchThree
{
    public partial class UserDataSerializer
    {
        private static List<IBaseDataController> _dataControllers;

        private static void RegisterDataController(IBaseDataController controller)
        {
            if (_dataControllers == null)
            {
                _dataControllers = new List<IBaseDataController>();
            }

            _dataControllers.Add(controller);
        }

        private static LocalIntDataController CreateLocalIntData(string key, int defaultValue = 0)
        {
            var controller = new LocalIntDataController(key, defaultValue);
            RegisterDataController(controller);
            return controller;
        }

        private static LocalBoolDataController CreateLocalBoolData(string key, bool defaultValue = false)
        {
            var controller = new LocalBoolDataController(key, defaultValue);
            RegisterDataController(controller);
            return controller;
        }

        private static LocalDateTimeDataController CreateLocalDateTimeData(string key, DateTime? defaultValue = null)
        {
            var controller = new LocalDateTimeDataController(key, defaultValue);
            RegisterDataController(controller);
            return controller;
        }


#region Predefined

        private static LocalIntDataController _gemController = CreateLocalIntData(CommonKeys.Gem);

        public static int Gem
        {
            get => _gemController.Value;
            set => _gemController.Value = value;
        }

        private static LocalIntDataController _currentLevel = CreateLocalIntData(CommonKeys.CurrentLevel, 1);

        public static int CurrentLevel
        {
            get => _currentLevel.Value;
            set => _currentLevel.Value = value;
        }

        private static LocalIntDataController _maxLevel = CreateLocalIntData(CommonKeys.MaxLevel, 1);

        public static int MaxLevel
        {
            get => _maxLevel.Value;
            set => _maxLevel.Value = value;
        }

        private static LocalIntDataController _heart = CreateLocalIntData(CommonKeys.Heart, 5);

        public static int Heart
        {
            get => _heart.Value;
            set => _heart.Value = value;
        }

        private static LocalDateTimeDataController _lastHeartTime =
            CreateLocalDateTimeData(CommonKeys.LastHeartTime, null);

        public static System.DateTime? LastHeartTime
        {
            get => _lastHeartTime.Value;
            set => _lastHeartTime.Value = value;
        }

        private static LocalBoolDataController _soundEnabled = CreateLocalBoolData(CommonKeys.Sound, true);

        public static bool SoundEnabled
        {
            get => _soundEnabled.Value;
            set => _soundEnabled.Value = value;
            // AudioManager.SoundEnabled = value;
        }

        private static LocalBoolDataController _musicEnabled = CreateLocalBoolData(CommonKeys.Music, true);

        public static bool MusicEnabled
        {
            get => _musicEnabled.Value;
            set => _musicEnabled.Value = value;
        }

        private static LocalBoolDataController _vibrationEnabled = CreateLocalBoolData(CommonKeys.Vibration, true);

        public static bool VibrationEnabled
        {
            get => _vibrationEnabled.Value;
            set => _vibrationEnabled.Value = value;
        }

        private static LocalBoolDataController _menuUnlocked =
            CreateLocalBoolData(CommonKeys.MenuUnlocked, true);

        public static bool MenuUnlocked
        {
            get => true;
            set => _menuUnlocked.Value = value;
        }

        private static LocalIntDataController _coin = CreateLocalIntData(CommonKeys.Coin, 1000);

        public static int Coin
        {
            get => _coin.Value;
            set => _coin.Value = value;
        }

        private static LocalIntDataController _boosterHammer = CreateLocalIntData(CommonKeys.BoosterHammer, 3);

        public static int BoosterHammer
        {
            get => _boosterHammer.Value;
            set => _boosterHammer.Value = value;
        }

        private static LocalIntDataController _boosterBow = CreateLocalIntData(CommonKeys.BoosterBow, 3);

        public static int BoosterBow
        {
            get => _boosterBow.Value;
            set => _boosterBow.Value = value;
        }

        private static LocalIntDataController _boosterWand = CreateLocalIntData(CommonKeys.BoosterWand, 3);

        public static int BoosterWand
        {
            get => _boosterWand.Value;
            set => _boosterWand.Value = value;
        }

        private static LocalIntDataController _boosterHat = CreateLocalIntData(CommonKeys.BoosterHat, 3);

        public static int BoosterHat
        {
            get => _boosterHat.Value;
            set => _boosterHat.Value = value;
        }

        private static LocalIntDataController _beginLightball = CreateLocalIntData(CommonKeys.BeginLightball, 3);

        public static int BeginLightBall
        {
            get => _beginLightball.Value;
            set => _beginLightball.Value = value;
        }

        private static LocalIntDataController _beginRocket = CreateLocalIntData(CommonKeys.BeginRocket, 3);

        public static int BeginRocket
        {
            get => _beginRocket.Value;
            set => _beginRocket.Value = value;
        }

        private static LocalIntDataController _beginTNT = CreateLocalIntData(CommonKeys.BeginTNT, 3);

        public static int BeginTNT
        {
            get => _beginTNT.Value;
            set => _beginTNT.Value = value;
        }

        private static LocalEnumHashSetDataController<ItemType> _playedItemTutorials = new(CommonKeys.ItemTutorial);

        private static HashSet<ItemType> _PlayedItemTutorials
        {
            get => _playedItemTutorials.Value;
            set => _playedItemTutorials.Value = value;
        }

        public static void SetPlayedItemTutorial(ItemType tutorialID)
        {
            _PlayedItemTutorials.Add(tutorialID);
            _playedItemTutorials.Write();
        }

        public static bool PlayedItemTutorial(ItemType tutorialID)
        {
            return _PlayedItemTutorials.Contains(tutorialID);
        }

        private static LocalEnumHashSetDataController<TutorialID> _playedTutorials = new(CommonKeys.Tutorial);

        private static HashSet<TutorialID> _PlayedTutorials
        {
            get => _playedTutorials.Value;
            set => _playedTutorials.Value = value;
        }

        public static void SetPlayedTutorial(TutorialID tutorialID)
        {
            _PlayedTutorials.Add(tutorialID);
            _playedTutorials.Write();
        }

        public static bool PlayedTutorial(TutorialID tutorialID)
        {
            return _PlayedTutorials.Contains(tutorialID);
        }

        private static TrainerData _trainerData = null;

        public static TrainerData TrainerData
        {
            get
            {
                if (_trainerData != null)
                {
                    return _trainerData;
                }

                _trainerData = new TrainerData();
                string saved = GetValue(CommonKeys.Trainer);
                if (saved.IsNullOrEmpty())
                {
                    return _trainerData;
                }
                _trainerData.Deserialize(saved);
                return _trainerData;
            }
        }

#endregion

#region Data Functions

#endregion

        public static void OnGUIDebug()
        {
            _maxLevel.OnGUI(value =>
            {
                SetMaxLevel(value);
                GameManager.SetDebugLevel(Mathf.Min(CurrentLevel, value));
            });
            _currentLevel.OnGUI(value => { SetCurrentLevel(value); });

            GUIHelper.Line();
            _coin.OnGUI(value => Coin = value);
            _heart.OnGUI(value => Heart = value);
            _lastHeartTime.OnGUI();

            GUIHelper.Line();
            _boosterHammer.OnGUI(value => BoosterHammer = value);
            _boosterBow.OnGUI(value => BoosterBow = value);
            _boosterWand.OnGUI(value => BoosterWand = value);
            _boosterHat.OnGUI(value => BoosterHat = value);

            GUIHelper.Line();
            _beginLightball.OnGUI();
            _beginRocket.OnGUI();
            _beginTNT.OnGUI();

            GUIHelper.Line();
            _soundEnabled.OnGUI();
            _musicEnabled.OnGUI();
            // _tutorialFlagsController.OnGUI();

            GUIHelper.Line();
            // _newChapterController.OnGUI();
            _menuUnlocked.OnGUI();
            _playedItemTutorials.OnGUI();
        }
    }
}